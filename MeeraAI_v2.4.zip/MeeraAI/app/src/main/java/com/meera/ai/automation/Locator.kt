package com.meera.ai.automation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Reads the phone's real GPS/network location - ONLY when the user said "yes" to "Can I check your location now?"
 * (see [LocationFlow]). Privacy rules of v2.4:
 *  - The location is NEVER given to Gemini: no tool returns it, no prompt contains it, no chat/memory/log/Live message carries it.
 *  - It is shown on the screen and spoken by the phone's own text-to-speech, nothing else.
 *  - [last] lives in RAM only and disappears after [TTL_MS] (2 minutes). Nothing is written to disk.
 * Accuracy is whatever Android reports (we say it honestly): outdoors usually 5-30 m, indoors it can be much worse.
 */
object Locator {
    class Fix(
        val lat: Double, val lon: Double, val accuracyM: Float, val ageSec: Long, val provider: String, val address: String?,
        val at: Long = System.currentTimeMillis()
    )

    sealed class Outcome {
        class Found(val fix: Fix) : Outcome()
        /** Nothing could be read; [text] is a message for the SCREEN / phone voice only (it contains no position). */
        class Problem(val text: String) : Outcome()
    }

    const val TTL_MS = 120_000L

    @Volatile private var lastFix: Fix? = null
    private var clearJob: Job? = null

    /** Last fix of this app run, RAM only, valid for 2 minutes. */
    val last: Fix?
        get() {
            val f = lastFix ?: return null
            if (System.currentTimeMillis() - f.at > TTL_MS) { lastFix = null; return null }
            return f
        }

    private fun keep(f: Fix) {
        lastFix = f
        clearJob?.cancel()
        clearJob = Meera.scope.launch { delay(TTL_MS); lastFix = null }
    }

    fun clear() { clearJob?.cancel(); lastFix = null }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasFine(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Called only from [LocationFlow] after the user's "yes". */
    suspend fun read(): Outcome {
        val ctx = Meera.app
        if (!hasPermission(ctx)) {
            val ask = Meera.requestLocation
            return if (ask != null) {
                ask()
                Outcome.Problem("Location permission is needed. Please tap Allow, then ask \"where am I?\" again.")
            } else Outcome.Problem("Location permission is missing. Allow Location in Meera's Permissions screen.")
        }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val gpsOn = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
        val netOn = try { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { false }
        if (!gpsOn && !netOn) return Outcome.Problem("Location services are switched OFF on the phone. Turn on Location in Android settings and ask again.")
        val fix = current(ctx, lm, gpsOn, netOn)
            ?: return Outcome.Problem("I could not get a location fix in time. Go near a window or outside and ask again.")
        keep(fix)
        return Outcome.Found(fix)
    }

    /** "good" / "fair" / "poor" wording for the accuracy, used on the card and in the spoken answer. */
    fun quality(accM: Float): String = when {
        accM <= 30f -> "good"
        accM <= 100f -> "fair"
        else -> "poor"
    }

    @SuppressLint("MissingPermission")
    private suspend fun current(ctx: Context, lm: LocationManager, gpsOn: Boolean, netOn: Boolean): Fix? {
        val providers = ArrayList<String>()
        if (gpsOn && hasFine(ctx)) providers.add(LocationManager.GPS_PROVIDER)
        if (netOn) providers.add(LocationManager.NETWORK_PROVIDER)
        var loc: Location? = null
        for (p in providers) {
            loc = fresh(ctx, lm, p)
            if (loc != null) break
        }
        if (loc == null) {
            // fall back to the freshest last known position (max 10 minutes old)
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                if (l != null && (loc == null || l.time > loc.time)) loc = l
            }
            if (loc != null && System.currentTimeMillis() - loc.time > 10 * 60_000L) loc = null
        }
        val l = loc ?: return null
        val ageSec = ((SystemClock.elapsedRealtimeNanos() - l.elapsedRealtimeNanos) / 1_000_000_000L).coerceAtLeast(0L)
        val addr = withContext(Dispatchers.IO) { address(ctx, l.latitude, l.longitude) }
        return Fix(l.latitude, l.longitude, if (l.hasAccuracy()) l.accuracy else 9999f, ageSec, l.provider ?: "?", addr)
    }

    @SuppressLint("MissingPermission")
    private suspend fun fresh(ctx: Context, lm: LocationManager, provider: String): Location? =
        withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<Location?> { cont ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val cs = CancellationSignal()
                    cont.invokeOnCancellation { cs.cancel() }
                    lm.getCurrentLocation(provider, cs, ContextCompat.getMainExecutor(ctx)) { l ->
                        if (cont.isActive) cont.resume(l)
                    }
                } else {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(l: Location) {
                            lm.removeUpdates(this)
                            if (cont.isActive) cont.resume(l)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(p: String?, status: Int, extras: Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {}
                    }
                    lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                    cont.invokeOnCancellation { lm.removeUpdates(listener) }
                }
            }
        }

    @Suppress("DEPRECATION")
    private fun address(ctx: Context, lat: Double, lon: Double): String? = try {
        if (!Geocoder.isPresent()) null
        else Geocoder(ctx, Locale.ENGLISH).getFromLocation(lat, lon, 1)?.firstOrNull()?.let { a ->
            (0..a.maxAddressLineIndex).map { a.getAddressLine(it) }.filter { !it.isNullOrBlank() }.joinToString(", ").ifBlank { null }
        }
    } catch (e: Exception) {
        null
    }
}
