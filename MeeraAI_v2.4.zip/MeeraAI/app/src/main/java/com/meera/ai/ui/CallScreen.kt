package com.meera.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.voice.CallState

/**
 * Call screen (v2.4): Meera fills the whole 9:16 screen as a video (no circle, no frame).
 * Before the call she waits with the NORMAL expression; during the call her expression follows what is happening
 * (listening = normal, thinking = thinking, speaking = talking clips, with the emotion of her words shown first).
 * Every change is a soft mix (see VideoCrossfade), so it looks like one person changing expression.
 */
@Composable
fun CallScreen(onBack: () -> Unit) {
    val call = Meera.call
    val ctx = LocalContext.current
    val view = LocalView.current
    val state by call.state.collectAsState()
    val status by call.status.collectAsState()
    val subs by call.subtitles.collectAsState()
    val muted by call.muted.collectAsState()
    val speaker by call.speaker.collectAsState()
    val secs by call.seconds.collectAsState()
    val mode by call.modeLabel.collectAsState()
    val callMood by call.callMood.collectAsState()
    val privateSpeech by call.privateSpeech.collectAsState()
    val inCall = state != CallState.Idle && state != CallState.Error
    val list = rememberLazyListState()

    // keep the screen awake during a call; the call itself keeps running in the background service
    DisposableEffect(inCall) {
        view.keepScreenOn = inCall
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(subs.size, subs.lastOrNull()?.text) {
        if (subs.isNotEmpty()) list.scrollToItem(subs.size - 1)
    }

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) call.start() else call.status.value = "Microphone permission denied. Allow it in Permissions screen."
    }
    fun startCall() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) call.start()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    val avMood = when (state) {
        CallState.Thinking -> "thinking"
        CallState.Error -> "sad"
        CallState.Speaking -> callMood
        else -> "normal"
    }
    val speaking = state == CallState.Speaking || privateSpeech

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AvatarStage(mood = avMood, speaking = speaking)

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to Color(0x6602040F), 0.16f to Color.Transparent, 0.60f to Color.Transparent, 1f to Color(0xAA02040F)
        )))

        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 16.dp, vertical = 10.dp)) {
            // top bar: back | name + timer
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(onBack, Modifier.size(44.dp)) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                GlassPill(
                    if (inCall) "Meera  •  %02d:%02d  •  %s".format(secs / 60, secs % 60, mode) else "Meera  •  AI voice call",
                    dot = when (state) {
                        CallState.Listening -> Cyan
                        CallState.Speaking -> Pink
                        CallState.Thinking -> Purple
                        CallState.Error -> Color(0xFFFF4D6D)
                        else -> Color(0xFF8FA0C8)
                    }
                )
            }

            Box(Modifier.weight(1f))

            // state + status line
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    when (state) {
                        CallState.Idle -> "Ready"
                        CallState.Connecting -> "Connecting…"
                        CallState.Listening -> "Listening"
                        CallState.Thinking -> "Thinking"
                        CallState.Speaking -> "Speaking"
                        CallState.Error -> "Problem"
                    },
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp
                )
                if (status.isNotBlank()) Text(
                    status, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp),
                    color = if (state == CallState.Error) Color(0xFFFF8FA0) else Color.White.copy(alpha = 0.75f)
                )
            }

            // live captions in a small glass panel (last lines only, so Meera's face stays visible)
            if (subs.isNotEmpty()) {
                LazyColumn(
                    Modifier.padding(top = 10.dp).fillMaxWidth().heightIn(max = 120.dp)
                        .glass(RoundedCornerShape(20.dp), 0.9f).padding(horizontal = 14.dp, vertical = 8.dp),
                    state = list, verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    items(subs) { s ->
                        Text("${s.who}: ${s.text}", color = if (s.who == "You") Cyan else Color(0xFFFFB3DD), fontSize = 14.sp)
                    }
                }
            }

            Box(Modifier.padding(top = 14.dp))

            if (inCall) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
                    CallBtn(if (muted) "🔇" else "🎙", if (muted) "Unmute" else "Mute", { call.toggleMute() }, active = muted)
                    CallBtn("✋", "Interrupt", { call.interrupt() })
                    CallBtn(if (speaker) "🔊" else "📱", if (speaker) "Speaker" else "Ear", { call.toggleSpeaker() })
                    CallBtn(null, "End", { call.stop() }, tint = Color(0xFFE5484D))
                }
            } else {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    GlassButton(
                        { startCall() }, Modifier.fillMaxWidth(0.8f).height(60.dp),
                        RoundedCornerShape(30.dp), tint = Color(0xFF22C55E), strength = 1.2f
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Filled.Call, null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Text("Start call", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text(
                        "Tip: talking while Meera speaks works best with headphones.",
                        fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f), modifier = Modifier.padding(top = 8.dp), textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun CallBtn(glyph: String?, label: String, onClick: () -> Unit, active: Boolean = false, tint: Color? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        GlassButton(onClick, Modifier.size(62.dp), CircleShape, tint = tint ?: if (active) Color(0xFFFFB020) else null, strength = 1.1f) {
            if (glyph != null) Text(glyph, fontSize = 22.sp)
            else Icon(Icons.Filled.Call, "End call", tint = Color.White, modifier = Modifier.size(26.dp))
        }
        GlassLabel(label)
    }
}
