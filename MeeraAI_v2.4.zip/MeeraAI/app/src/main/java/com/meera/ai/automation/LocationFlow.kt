package com.meera.ai.automation

import com.meera.ai.Meera
import com.meera.ai.ToolOut
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** What the on-screen location card shows. Lives in RAM only and is cleared after 2 minutes. */
class LocationCardData(val title: String, val body: String, val fix: Locator.Fix?)

/**
 * The ONLY way Meera ever reads the phone's location:
 *   1. the app itself recognizes "where am I?" ([WhereAmI], local text match - not Gemini),
 *   2. it asks "Can I check your location now? (yes / no)"  (same yes/no mechanism as Meera.confirmThen),
 *   3. only after the user's own "yes" the location is read,
 *   4. the answer goes to the screen (card + toast) and to the phone's own text-to-speech - NOTHING else:
 *      not Gemini, not the chat history / saved chat file, not memory, not logs, not the Live session.
 * "No" (or any other answer) does nothing. Nothing here runs in the background or because Gemini asked for it.
 */
object LocationFlow {
    const val QUESTION = "Can I check your location now? (yes / no)"
    private const val CARD_MS = 120_000L
    private var speechToken = 0

    /** Start the question. The text of the returned [ToolOut] contains no location. */
    fun ask(): ToolOut = Meera.confirmThen(QUESTION, local = true) {
        begin()
        "Okay, checking your location now. I will show it on the screen."
    }

    private fun begin() {
        Meera.scope.launch {
            when (val r = Locator.read()) {
                is Locator.Outcome.Found -> show(r.fix)
                is Locator.Outcome.Problem -> {
                    publish(LocationCardData("Location", r.text, null))
                    Meera.toast(r.text)
                    sayPrivately(r.text)
                }
            }
        }
    }

    private fun show(f: Locator.Fix) {
        val acc = Math.round(f.accuracyM)
        val q = Locator.quality(f.accuracyM)
        val qText = when (q) {
            "good" -> "good"
            "fair" -> "fair"
            else -> "poor, the real position may be several hundred metres away"
        }
        val addr = f.address
        val body = buildString {
            append(addr ?: "No street address is available on this phone.")
            append("\nAccuracy: about $acc m ($qText)")
            append("\n${"%.5f".format(Locale.US, f.lat)}, ${"%.5f".format(Locale.US, f.lon)}")
        }
        publish(LocationCardData("You are here", body, f))
        val spoken = (if (addr != null) "You are near $addr. " else "I found your position but no street address. ") +
            "The accuracy is about $acc metres, which is $q."
        Meera.toast((addr ?: "Position found") + "  (±$acc m)")
        sayPrivately(spoken)
    }

    private fun publish(card: LocationCardData) {
        Meera.locationCard.value = card
        Meera.scope.launch {
            delay(CARD_MS)
            if (Meera.locationCard.value === card) Meera.locationCard.value = null
        }
    }

    /** Dismiss the card now (also forgets the RAM copy). */
    fun dismiss() {
        Meera.locationCard.value = null
        Locator.clear()
    }

    /**
     * Speak with the PHONE's text-to-speech only. During a call the microphone is paused while this is spoken
     * ([com.meera.ai.voice.CallController.beginPrivateSpeech]), so the address can never reach Gemini through the speaker.
     */
    fun sayPrivately(text: String) {
        val tok = ++speechToken
        Meera.call.beginPrivateSpeech()
        Meera.tts.speak(text) { Meera.scope.launch { if (tok == speechToken) Meera.call.endPrivateSpeech() } }
        // fail-safe: if the speech engine never reports "done", give the microphone back after 25 s
        Meera.scope.launch { delay(25_000); if (tok == speechToken) Meera.call.endPrivateSpeech() }
    }
}
