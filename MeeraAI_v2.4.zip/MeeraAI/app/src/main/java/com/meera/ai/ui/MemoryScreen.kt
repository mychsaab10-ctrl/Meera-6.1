package com.meera.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.data.Memory
import java.text.DateFormat
import java.util.Date

@Composable
fun MemoryScreen(onBack: () -> Unit) {
    val items by Meera.memory.items.collectAsState()
    var editing by remember { mutableStateOf<Memory?>(null) }
    var editText by remember { mutableStateOf("") }
    var newText by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }

    SubScreen("Memory", onBack) {
        Text(
            "Meera remembers lasting things you tell her automatically (turn this off in Settings -> Memory) and anything you ask her to remember. Everything is stored only on this phone. You can edit or delete any memory. Passwords, OTPs and card/ID numbers are never saved automatically.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
        )
        OutlinedTextField(
            newText, { newText = it }, Modifier.fillMaxWidth(),
            label = { Text("Add a memory (for example: I like tea)") }
        )
        Button(onClick = { Meera.memory.add("fact", newText); newText = "" }, enabled = newText.isNotBlank()) { Text("Add") }
        SectionTitle("Built in (cannot be changed)")
        com.meera.ai.data.CoreFacts.lines.forEach { line ->
            GlowCard(Modifier.fillMaxWidth()) {
                Text("core • locked 🔒", fontSize = 11.sp, color = Cyan)
                Text(line, color = MaterialTheme.colorScheme.onSurface)
            }
        }
        SectionTitle("Saved (${items.size})")
        if (items.isEmpty()) Text("No saved memories yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        items.forEach { m ->
            GlowCard(Modifier.fillMaxWidth()) {
                Text("${m.kind} • ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(m.ts))}", fontSize = 11.sp, color = Cyan)
                Text(m.text, color = MaterialTheme.colorScheme.onSurface)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { editing = m; editText = m.text }) { Text("Edit") }
                    TextButton(onClick = { Meera.memory.delete(m.id) }) { Text("Delete") }
                }
            }
        }
        if (items.isNotEmpty()) OutlinedButton(onClick = { confirmClear = true }) { Text("Clear all memory") }
    }

    editing?.let { m ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit memory") },
            text = { OutlinedTextField(editText, { editText = it }, Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { Meera.memory.update(m.id, editText); editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear ALL memory?") },
            text = { Text("This cannot be undone. The built-in facts about your owner stay.") },
            confirmButton = { TextButton(onClick = { Meera.memory.clearAll(); confirmClear = false }) { Text("Delete everything") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}
