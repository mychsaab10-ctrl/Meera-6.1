package com.meera.ai.ui

import androidx.annotation.RawRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.meera.ai.R
import kotlinx.coroutines.delay

/**
 * THE ONLY PLACE that says which video file is which expression.
 * The nine supplied videos were matched to expressions by LOOKING at them (no labels came with them).
 * If one is wrong, just swap the file names here (res/raw/*.mp4) - nothing else in the app needs to change.
 *
 *   avatar_normal   - calm face, slight movement           (idle / listening)
 *   avatar_blink    - calm face with several blinks         (alternates with normal so she looks alive)
 *   avatar_talk     - mouth moving                          (speaking, variant 1)
 *   avatar_speaking - mouth moving, a bit livelier          (speaking, variant 2)
 *   avatar_sad      - sad face                              (sad)
 *   avatar_excited  - wide eyes, big smile                  (excited)
 *   avatar_thinking - eyes down / head tilt                 (thinking)
 *   avatar_happy    - warm smile                            (happy, loving)
 *   home_scene      - girl working on a holographic console (Home screen background)
 */
object AvatarClips {
    class Clip(@RawRes val res: Int, val ms: Int)

    val NORMAL = Clip(R.raw.avatar_normal, 8000)
    val BLINK = Clip(R.raw.avatar_blink, 8000)
    val TALK = Clip(R.raw.avatar_talk, 8000)
    val SPEAKING = Clip(R.raw.avatar_speaking, 8000)
    val SAD = Clip(R.raw.avatar_sad, 8000)
    val EXCITED = Clip(R.raw.avatar_excited, 7900)
    val THINKING = Clip(R.raw.avatar_thinking, 7900)
    val HAPPY = Clip(R.raw.avatar_happy, 8000)
    val HOME = Clip(R.raw.home_scene, 10000)

    /** Clip for a silent (not speaking) mood. */
    fun still(mood: String): Clip = when (mood) {
        "sad" -> SAD
        "excited" -> EXCITED
        "thinking" -> THINKING
        "happy", "loving" -> HAPPY
        else -> NORMAL
    }

    /** While she is speaking the mouth must move, so talking clips are used; an emotion is shown first (see [AvatarStage]). */
    val talkPool = listOf(TALK, SPEAKING)
}

/** The next clip is requested this long before the current one ends, so the mix effect hides the loop seam. */
private const val SEAM_MS = 900L

/** How long the emotion of her words is shown at the start of a spoken sentence before the mouth-moving clips take over. */
private const val ACCENT_MS = 2600L

/**
 * Full-screen Meera. Decides WHICH clip plays; [VideoCrossfade] makes every change (and every loop restart) a soft mix,
 * so it feels like one continuous person whose expression changes - not like another video starting.
 *
 *  - not speaking: the clip of the mood (normal alternates with the blinking clip)
 *  - speaking: if the words carry an emotion (excited / sad / happy / loving) it is shown first for a moment,
 *    then the two talking clips alternate while she speaks; when the mood changes mid-sentence the new emotion is shown again.
 */
@Composable
fun AvatarStage(mood: String, speaking: Boolean, modifier: Modifier = Modifier) {
    var req by remember { mutableStateOf(ClipReq(AvatarClips.NORMAL.res, 0)) }
    LaunchedEffect(mood, speaking) {
        var n = req.nonce
        suspend fun play(c: AvatarClips.Clip, holdMs: Long) {
            n++
            req = ClipReq(c.res, n)
            delay(holdMs)
        }
        if (speaking) {
            if (mood != "normal" && mood != "thinking") play(AvatarClips.still(mood), ACCENT_MS)
            var i = 0
            while (true) {
                val c = AvatarClips.talkPool[i++ % AvatarClips.talkPool.size]
                play(c, c.ms - SEAM_MS)
            }
        } else if (mood == "normal") {
            while (true) {
                play(AvatarClips.NORMAL, AvatarClips.NORMAL.ms - SEAM_MS)
                play(AvatarClips.BLINK, AvatarClips.BLINK.ms - SEAM_MS)
            }
        } else {
            val c = AvatarClips.still(mood)
            while (true) play(c, c.ms - SEAM_MS)
        }
    }
    VideoCrossfade(req, R.drawable.poster_avatar, modifier, fadeMs = 450)
}

/** Home screen: the sci-fi scene, looped with a soft mix at the restart (and a fade-in at the very start). */
@Composable
fun HomeScene(modifier: Modifier = Modifier) {
    var req by remember { mutableStateOf(ClipReq(AvatarClips.HOME.res, 0)) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            delay(AvatarClips.HOME.ms - SEAM_MS - 300)
            n++
            req = ClipReq(AvatarClips.HOME.res, n)
        }
    }
    VideoCrossfade(req, R.drawable.poster_home, modifier, fadeMs = 800, introMs = 900)
}
